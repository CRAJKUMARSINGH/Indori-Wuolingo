# Gujarati-Hindi Mini PRD

## Product summary

This branch is a compact bilingual learning track inside `Indori-Wuolingo` focused on practical communication between `Gujarati` and `Hindi`. It is designed as a small pilot that can serve consumer learners, schools, relocation programs, and enterprise training teams.

## Goal

The first version should help learners understand and use common everyday phrases between `Gujarati` and `Hindi` without forcing a full grammar-heavy program from day one.

## Target users

- Gujarati speakers who want usable Hindi for daily life, school, travel, or work
- Hindi speakers who want usable Gujarati for relocation, community, or business contexts
- institutions that need a short regional language bridge program

## Problem

Many learners do not need full academic fluency at the start. They need a practical bridge: greetings, directions, shopping, family conversation, work basics, and pronunciation support. Existing language products often miss this short-path regional need.

## Release scope

### In scope

- bidirectional language selection: `Gujarati -> Hindi` and `Hindi -> Gujarati`
- first 8 practical units
- phrase-based lessons
- transliteration support
- audio playback for both languages
- basic quiz types: match, choose, reorder, listen
- simple review loop for weak phrases

### Out of scope

- deep grammar explanations
- advanced writing practice
- long-form reading passages
- live conversation or tutoring
- certification workflows

## User flow

1. learner chooses a direction
2. learner sees the first practical unit
3. learner studies short phrases with audio and transliteration
4. learner completes 3 to 6 exercises
5. learner gets a score, XP, and recommended review items
6. learner returns later for spaced repetition

## First unit set

| Unit | Content |
|---|---|
| `1` | greetings and introductions |
| `2` | family members and simple conversation |
| `3` | numbers, time, and dates |
| `4` | directions and transport |
| `5` | shopping and payments |
| `6` | food, home, and daily phrases |
| `7` | school and workplace basics |
| `8` | mixed review and real-life scenarios |

## Content model

Each phrase record should include:

- source phrase
- target phrase
- native script
- transliteration
- literal meaning
- natural usage meaning
- audio asset
- regional note if needed

## Functional requirements

### Language pair selection

The app should clearly show both directions at entry:

- `Gujarati -> Hindi`
- `Hindi -> Gujarati`

The user should always know which direction they are currently studying.

### Lesson card

Each lesson should show:

- unit name
- estimated time
- phrase count
- lesson status
- review badge if weak items are included

### Exercise types

The first release should support:

- phrase match
- meaning selection
- audio recognition
- word order reconstruction
- quick recall review

### Transliteration

Transliteration should be optional but easy to reveal. It should help beginners, not replace script exposure forever.

### Audio

Each core phrase should have a clean native-speaker audio clip. Audio speed should be natural but not rushed.

### Review logic

Wrong or slow answers should increase the chance a phrase comes back in review. The learner should feel that the app remembers weak spots.

## Success metrics

- first unit completion rate
- 8-unit path completion rate
- review return rate
- phrase recognition improvement over repeated sessions
- average lesson completion time

## Risks

| Risk | Response |
|---|---|
| learners depend too much on transliteration | reduce visibility over time and increase script exposure gradually |
| phrases feel too formal or unnatural | review content with native speakers from both sides |
| branch feels too small to matter | package it as a strong regional starter program, not a full language degree |
| bidirectional content doubles workload | use shared phrase structures and parallel authoring templates |

## Launch recommendation

Launch this branch as a tightly scoped pilot with 8 units, measure completion and review behavior, then decide whether to deepen the pair or add another regional duo branch.
