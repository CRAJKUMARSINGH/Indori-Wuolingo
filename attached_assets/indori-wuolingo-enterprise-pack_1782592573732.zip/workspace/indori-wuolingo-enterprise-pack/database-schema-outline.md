# Database Schema Outline

This outline covers the main data entities for an enterprise-grade `Indori-Wuolingo` platform with a `Gujarati <-> Hindi` pilot branch.

## Core entities

### Identity and tenant

| Table | Purpose | Key fields |
|---|---|---|
| `users` | all platform users | `id`, `email`, `phone`, `name`, `status`, `last_login_at` |
| `organizations` | enterprise customers or institutions | `id`, `name`, `type`, `status`, `branding_config`, `domain` |
| `organization_memberships` | user membership within a tenant | `id`, `organization_id`, `user_id`, `role`, `status` |
| `sso_connections` | enterprise identity setup | `id`, `organization_id`, `provider_type`, `metadata`, `enabled` |
| `seats` | paid or assigned learner capacity | `id`, `organization_id`, `plan_id`, `allocated_count`, `used_count` |

### Learning catalog

| Table | Purpose | Key fields |
|---|---|---|
| `languages` | supported languages | `id`, `code`, `name`, `script`, `status` |
| `language_pairs` | source-target combinations | `id`, `source_language_id`, `target_language_id`, `status` |
| `courses` | top-level learning tracks | `id`, `language_pair_id`, `title`, `level`, `status` |
| `units` | grouped lesson modules | `id`, `course_id`, `title`, `sort_order` |
| `lessons` | individual lessons | `id`, `unit_id`, `title`, `difficulty`, `estimated_minutes`, `status` |
| `exercise_templates` | reusable exercise definitions | `id`, `type`, `config_json`, `status` |
| `lesson_exercises` | exercise instances inside lessons | `id`, `lesson_id`, `exercise_template_id`, `sort_order`, `content_json` |
| `assets` | audio and media references | `id`, `asset_type`, `storage_key`, `duration_ms`, `metadata_json` |

### Phrase and vocabulary data

| Table | Purpose | Key fields |
|---|---|---|
| `lexicon_entries` | vocabulary or phrase records | `id`, `language_id`, `text`, `transliteration`, `literal_meaning`, `usage_note` |
| `translations` | mapped meaning pairs | `id`, `source_entry_id`, `target_entry_id`, `confidence`, `review_status` |
| `pronunciation_guides` | speech support records | `id`, `entry_id`, `phonetic_text`, `audio_asset_id` |
| `regional_variants` | dialect or usage variations | `id`, `entry_id`, `region_code`, `variant_text`, `note` |

### Learner progress

| Table | Purpose | Key fields |
|---|---|---|
| `learner_profiles` | learner preferences and goals | `id`, `user_id`, `daily_goal_minutes`, `current_course_id`, `native_language_id` |
| `lesson_attempts` | each lesson completion attempt | `id`, `user_id`, `lesson_id`, `score`, `completed_at`, `duration_seconds` |
| `exercise_attempts` | detailed exercise outcomes | `id`, `lesson_attempt_id`, `exercise_id`, `result`, `response_json`, `latency_ms` |
| `mastery_records` | tracked skill strength | `id`, `user_id`, `lexicon_entry_id`, `mastery_score`, `last_reviewed_at` |
| `review_queue_items` | spaced repetition scheduling | `id`, `user_id`, `lexicon_entry_id`, `due_at`, `priority`, `state` |
| `streaks` | daily habit state | `id`, `user_id`, `current_count`, `best_count`, `last_active_date` |
| `xp_ledgers` | XP and reward history | `id`, `user_id`, `event_type`, `xp_delta`, `created_at` |

### Classroom and enterprise workflows

| Table | Purpose | Key fields |
|---|---|---|
| `cohorts` | class or team grouping | `id`, `organization_id`, `name`, `type`, `status` |
| `cohort_memberships` | learners inside cohorts | `id`, `cohort_id`, `user_id`, `status` |
| `assignments` | scheduled learning tasks | `id`, `organization_id`, `course_id`, `title`, `start_at`, `due_at` |
| `assignment_targets` | assignment recipient groups | `id`, `assignment_id`, `cohort_id`, `user_id` |
| `assignment_progress` | learner progress on assignments | `id`, `assignment_id`, `user_id`, `completion_percent`, `status` |
| `report_exports` | generated export jobs | `id`, `organization_id`, `type`, `requested_by`, `status`, `file_key` |

### Operations and governance

| Table | Purpose | Key fields |
|---|---|---|
| `plans` | subscription plans | `id`, `name`, `billing_period`, `feature_flags_json` |
| `subscriptions` | active billing relationships | `id`, `organization_id`, `plan_id`, `status`, `renewal_date` |
| `feature_flags` | controlled feature rollout | `id`, `key`, `scope_type`, `scope_id`, `enabled` |
| `audit_logs` | sensitive action tracking | `id`, `organization_id`, `actor_user_id`, `event_type`, `target_type`, `target_id`, `payload_json`, `created_at` |
| `support_cases` | internal support tracking | `id`, `organization_id`, `opened_by`, `status`, `summary` |

## Relationship summary

- one `organization` has many `organization_memberships`, `cohorts`, `assignments`, `subscriptions`, and `audit_logs`
- one `language_pair` has many `courses`
- one `course` has many `units`, and one `unit` has many `lessons`
- one `lesson` has many `lesson_exercises`
- one `user` has one `learner_profile` and many `lesson_attempts`, `review_queue_items`, and `xp_ledgers`
- one `assignment` can target many cohorts or individual users

## Gujarati-Hindi branch notes

For the `Gujarati <-> Hindi` pilot, make sure the schema supports:

- bidirectional `language_pairs`
- native script plus transliteration
- phrase-level content, not only single-word vocabulary
- optional regional notes for alternate forms
- audio assets for both languages

## Practical implementation advice

- keep transactional tables in `PostgreSQL`
- use object storage for audio, export files, and rich media
- move large reporting reads to a warehouse or replica once enterprise reporting grows
- version content records so lesson changes do not break old learner progress histories
