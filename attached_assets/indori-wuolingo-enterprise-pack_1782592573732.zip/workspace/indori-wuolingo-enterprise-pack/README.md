# Indori-Wuolingo Enterprise Pack

This package contains four follow-up planning documents for the `Indori-Wuolingo` enterprise-grade direction and the `Gujarati <-> Hindi` pilot branch.

## Included files

- `architecture-diagram.md`: enterprise system architecture with a Mermaid diagram
- `database-schema-outline.md`: core entities, relationships, and schema notes
- `feature-backlog.md`: prioritized backlog across learner, enterprise, content, and platform tracks
- `gujarati-hindi-mini-prd.md`: compact PRD for the bilingual pilot branch

## Recommended reading order

1. `architecture-diagram.md`
2. `database-schema-outline.md`
3. `feature-backlog.md`
4. `gujarati-hindi-mini-prd.md`
