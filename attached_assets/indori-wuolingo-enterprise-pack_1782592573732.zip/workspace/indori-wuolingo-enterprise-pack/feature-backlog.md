# Feature Backlog

This backlog is organized for a first enterprise-grade build of `Indori-Wuolingo` with a small `Gujarati <-> Hindi` pilot branch.

## Priority legend

- `P0`: must have for the first real release
- `P1`: next layer after the first stable release
- `P2`: useful expansion after enterprise basics are working

## Backlog by epic

| Epic | Priority | Feature | Outcome |
|---|---|---|---|
| Learner onboarding | `P0` | language pair selection | learner starts the right path quickly |
| Learner onboarding | `P0` | daily goal setup | establishes habit expectations early |
| Learner onboarding | `P0` | beginner placement entry | separates new users from returning learners |
| Lesson delivery | `P0` | lesson player shell | reusable container for all lesson types |
| Lesson delivery | `P0` | phrase match and translation exercises | supports fast beginner learning |
| Lesson delivery | `P0` | audio playback | enables listening and pronunciation familiarity |
| Review and mastery | `P0` | spaced repetition queue | improves retention over time |
| Review and mastery | `P0` | mastery scoring | drives review recommendations |
| Motivation loop | `P0` | XP and streaks | increases repeat usage |
| Motivation loop | `P1` | badges and milestones | adds lightweight reward progression |
| Enterprise admin | `P0` | organization setup | allows customer onboarding |
| Enterprise admin | `P0` | role-based access control | separates learner, teacher, manager, admin permissions |
| Enterprise admin | `P0` | cohort management | supports group-based assignments |
| Enterprise admin | `P0` | assignment creation | enables class and team learning workflows |
| Enterprise reporting | `P0` | learner progress dashboard | gives admins visibility into usage and outcomes |
| Enterprise reporting | `P0` | CSV export | covers first reporting requests without heavy BI work |
| Enterprise reporting | `P1` | scheduled reports | reduces manual admin work |
| Content operations | `P0` | lesson authoring console | removes engineering bottlenecks for content updates |
| Content operations | `P0` | audio asset upload | supports listening flows |
| Content operations | `P1` | versioned publish and rollback | lowers release risk for content teams |
| Content operations | `P1` | reviewer workflow | supports language expert QA |
| Identity | `P0` | email and phone auth | baseline access for consumers |
| Identity | `P1` | `SSO` for enterprise | required for larger customers |
| Platform | `P0` | audit log for admin actions | supports trust and operational review |
| Platform | `P0` | monitoring and alerts | helps keep the system stable |
| Platform | `P1` | feature flags | safer rollout and customer-specific control |
| Platform | `P1` | backup and recovery workflows | improves enterprise readiness |
| Gujarati-Hindi branch | `P0` | bilingual phrase catalog | powers the pilot curriculum |
| Gujarati-Hindi branch | `P0` | transliteration support | helps early learners read faster |
| Gujarati-Hindi branch | `P0` | first 8 unit path | creates a usable starter program |
| Gujarati-Hindi branch | `P1` | speaking practice for core phrases | adds higher learning confidence |
| Gujarati-Hindi branch | `P1` | regional phrase notes | improves real-world accuracy |

## Sprint-friendly release slices

### Slice 1

- signup and login
- language pair picker
- lesson player foundation
- first 10 lessons
- basic progress tracking

### Slice 2

- review queue
- XP and streaks
- audio playback
- content console v1
- analytics dashboard basics

### Slice 3

- organization setup
- roles and permissions
- cohorts and assignments
- learner progress reporting
- CSV exports

### Slice 4

- `SSO`
- audit logging
- scheduled reports
- publish and rollback tools
- support workflows

## Suggested user stories

### Learner

- As a learner, I want to choose `Gujarati -> Hindi` so I get lessons in the correct direction.
- As a learner, I want transliteration support so I can read unfamiliar script with less friction.
- As a learner, I want review sessions based on my weak answers so I remember useful phrases better.

### Teacher or manager

- As a teacher, I want to assign a unit to a class so I can track completion by learner.
- As a manager, I want to see who is behind on lessons so I can follow up quickly.

### Org admin

- As an org admin, I want to upload users and place them into cohorts so onboarding is fast.
- As an org admin, I want CSV exports so I can share progress data with my institution.

### Content specialist

- As a content editor, I want to publish a revised lesson without engineering help so curriculum updates move faster.
- As a language reviewer, I want to inspect transliteration and audio together so I can catch quality issues before release.

## Definition of done for `P0`

- core learner flows work on mobile
- enterprise admins can create a cohort and assign learning
- learners can complete lessons and generate progress records
- content team can publish at least one course without code changes
- audit logs exist for critical admin actions
