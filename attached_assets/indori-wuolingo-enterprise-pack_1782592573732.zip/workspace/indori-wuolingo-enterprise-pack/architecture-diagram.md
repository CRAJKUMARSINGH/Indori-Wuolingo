# Enterprise Architecture Diagram

This diagram shows a practical first architecture for an enterprise-grade version of `Indori-Wuolingo`.

```mermaid
flowchart TD
    A[Learner Mobile App]
    B[Web Admin Portal]
    C[Content Studio]

    A --> G[API Gateway]
    B --> G
    C --> G

    G --> D[Auth Service]
    G --> E[Tenant Service]
    G --> F[Learning Service]
    G --> H[Progress Service]
    G --> I[Content Service]
    G --> J[Reporting Service]
    G --> K[Notification Service]
    G --> L[Audit Service]

    D --> M[(PostgreSQL)]
    E --> M
    F --> M
    H --> M
    J --> M
    L --> M

    I --> N[(Object Storage)]
    I --> M
    K --> O[Push and Email Providers]
    J --> P[Analytics Warehouse]
    H --> P
    F --> P
    L --> P

    Q[SSO Providers] --> D
    R[Queue and Jobs] --> J
    R --> K
    R --> I

    S[Monitoring and Alerts] --> D
    S --> E
    S --> F
    S --> H
    S --> I
    S --> J
    S --> K
    S --> L
```

## Core surfaces

- `Learner Mobile App`: daily study, reviews, streaks, lesson progression
- `Web Admin Portal`: tenant setup, class and cohort management, reporting, exports
- `Content Studio`: internal lesson authoring, publishing, audio and phrase asset operations

## Core services

| Service | Responsibility |
|---|---|
| `Auth Service` | login, tokens, passwordless flows, `SSO`, identity mapping |
| `Tenant Service` | organizations, roles, seat entitlements, customer settings |
| `Learning Service` | units, lessons, exercise delivery, assignment targeting |
| `Progress Service` | XP, streaks, mastery, lesson state, review scheduling |
| `Content Service` | content versioning, assets, publishing, rollback |
| `Reporting Service` | dashboards, exports, scheduled reports |
| `Notification Service` | push reminders, admin alerts, assignment messages |
| `Audit Service` | admin actions, exports, publishing history, compliance logs |

## Deployment notes

- Start with a modular monolith or a small service split if the team is lean.
- Keep `auth`, `tenant`, `learning`, `progress`, and `content` boundaries explicit even if they deploy together at first.
- Use asynchronous jobs for exports, scheduled reports, notifications, and large content imports.
- Keep analytics and reporting workloads separate from the main transactional path once enterprise reporting grows.
