# Founder Roadmap

This document summarizes the founder-level build sequence for `Indori-Wuolingo`.

## Build order

### Step 1: prove the learner loop

The first job is to prove that users will start lessons, complete them, and come back. That means the product should focus on:

- a clean onboarding flow
- one strong language pair
- short lessons
- review and streak mechanics
- enough content to form a habit

### Step 2: prove the content pipeline

The team should not expand languages until it can reliably create, review, publish, and update lessons without engineering bottlenecks. This is the point where internal tooling becomes strategic, not optional.

### Step 3: prove one institutional workflow

Before going broad in enterprise, the company should support one real institutional use case well. For example:

- a school assigning lessons to a class
- an employer assigning a language path to a relocation group

### Step 4: prove commercial repeatability

The founder should test whether the product can close and support repeat accounts without custom rebuilding each time. That means standardizing:

- organization setup
- seat allocation
- cohort assignment
- progress reporting
- support process

## Founder priorities by stage

| Stage | Founder focus |
|---|---|
| `0-6 months` | product wedge, learner retention, content quality |
| `6-12 months` | content pipeline, mobile reliability, first pilots |
| `12-18 months` | enterprise basics, reporting, design of repeatable sales motion |
| `18-24 months` | pricing discipline, team scaling, stronger distribution |

## Decisions to get right early

- pick a sharp first language wedge
- avoid building for every persona at once
- treat content operations as core infrastructure
- keep enterprise scope narrow in the first release
- build metrics into the product from day one

## What not to do

- do not launch too many language pairs at once
- do not overbuild deep enterprise features before a real pilot
- do not rely only on generic AI output for learner-facing lessons
- do not confuse interest with retention

## Milestone view

1. first 100 active learners complete lessons
2. first 30 to 50 lessons feel stable
3. first retention loop shows repeat study behavior
4. first institution pilot runs with assignments and reporting
5. first paid repeatable contract closes

## Founder test

If the team had to explain the company in one sentence, it should be simple: `Indori-Wuolingo` helps people learn Indian languages in short mobile lessons and gives institutions a clean way to deploy and track language learning at scale.
