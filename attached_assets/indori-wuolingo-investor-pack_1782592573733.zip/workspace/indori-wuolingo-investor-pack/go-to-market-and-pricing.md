# Go-to-Market and Pricing

## Go-to-market approach

`Indori-Wuolingo` should not start with a giant national rollout. The smarter approach is to enter through a narrow, high-utility use case and then expand by adjacency.

## Recommended launch order

### Consumer-first wedge

Start with individual learners who need practical language support for daily life, school, work, or relocation. This creates fast feedback on the product and content.

### Institutional pilot wedge

After the learner experience is stable, move into one or two practical B2B or education pilots:

- schools with regional language bridge needs
- employers onboarding workers across states
- coaching or training centers

## Distribution ideas

- app store acquisition around specific language-pair keywords
- partnerships with schools and education networks
- relocation and workforce training partnerships
- community marketing in regional-language groups
- social content that teaches useful phrases and links into the app

## Pricing model

### Consumer

| Tier | Offer |
|---|---|
| Free | limited lessons, reviews, or hearts |
| Premium | unlimited study, advanced review, audio depth, speaking feedback |

### Institutional

| Customer type | Pricing shape |
|---|---|
| Small school or training center | simple annual package |
| Employer | seat-based plan |
| Large institution | contract pricing with onboarding and support |

## What to price for

The company should price for:

- active learners
- access to reporting and admin controls
- premium learning features
- support and onboarding for enterprise accounts

## Early commercial packaging

### Starter institution package

- 1 admin account
- up to a fixed learner cap
- cohort assignment
- learner progress reporting
- CSV exports

### Growth institution package

- more seats
- more admins
- scheduled reports
- `SSO`
- onboarding support

## Main commercial risk

If the product sells into institutions too early without a repeatable package, each customer becomes a custom project. The answer is to keep the first enterprise offer narrow and easy to explain.

## Strong positioning line

`Indori-Wuolingo` is the easiest way for learners and institutions to deploy practical Indian language learning in short, trackable, mobile-first lessons.
