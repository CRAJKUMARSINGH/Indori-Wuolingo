# Indori-Wuolingo Founder and Investor Pack

This package is a shorter, shareable set of planning documents for founder conversations, investor discussions, and early strategic reviews.

## Included files

- `executive-summary.md`
- `investor-memo.md`
- `founder-roadmap.md`
- `go-to-market-and-pricing.md`

## Best use

- share `executive-summary.md` first
- use `investor-memo.md` for fundraising discussions
- use `founder-roadmap.md` for internal alignment
- use `go-to-market-and-pricing.md` for early commercial planning
